module.exports = {
    login : 'sophiechatbot05@gmail.com',
    password : 'nicolassmith29285979'
}

